select * from main;
select * from country;
select * from currency1;
-- 1. Create calendar Table 
CREATE TABLE Calendar (Datekey DATE PRIMARY KEY,Year INT,MonthNo INT,MonthFullName VARCHAR(20),Quarter VARCHAR(2),YearMonth VARCHAR(10),WeekdayNo INT,
WeekdayName VARCHAR(20),FinancialMonth INT,FinancialQuarter VARCHAR(3));
select * from calendar;
INSERT INTO Calendar (Datekey)SELECT DISTINCT Datekey_Opening FROM main;
UPDATE Calendar
SET 
    Year = YEAR(Datekey),
    MonthNo = MONTH(Datekey),
    MonthFullName = MONTHNAME(Datekey),
    Quarter = CASE 
                WHEN MONTH(Datekey) BETWEEN 1 AND 3 THEN 'Q1'
                WHEN MONTH(Datekey) BETWEEN 4 AND 6 THEN 'Q2'
                WHEN MONTH(Datekey) BETWEEN 7 AND 9 THEN 'Q3'
                ELSE 'Q4'
              END,
    YearMonth = DATE_FORMAT(Datekey,'%Y-%b'),
    WeekdayNo = DAYOFWEEK(Datekey),
    WeekdayName = DAYNAME(Datekey),
	FinancialQuarter = CASE 
                        WHEN MONTH(Datekey) IN (4, 5, 6) THEN 'FQ1'
                        WHEN MONTH(Datekey) IN (7, 8, 9) THEN 'FQ2'
                        WHEN MONTH(Datekey) IN (10, 11, 12) THEN 'FQ3'
                        ELSE 'FQ4'
                      END;
  update calendar                    
SET FinancialMonth = CASE WHEN MONTH(Datekey) = 4 THEN 1
                      WHEN MONTH(Datekey) = 5 THEN 2
                      WHEN MONTH(Datekey) = 6 THEN 3
                      WHEN MONTH(Datekey) = 7 THEN 4
                      WHEN MONTH(Datekey) = 8 THEN 5
                      WHEN MONTH(Datekey) = 9 THEN 6
                      WHEN MONTH(Datekey) = 10 THEN 7
                      WHEN MONTH(Datekey) = 11 THEN 8
                      WHEN MONTH(Datekey) = 12 THEN 9
                      WHEN MONTH(Datekey) = 1 THEN 10
                      WHEN MONTH(Datekey) = 2 THEN 11
                      WHEN MONTH(Datekey) = 3 THEN 12
                      ELSE NULL END;
select * from calendar;

-- 2. Convert Average_Cost_for_2 to USD.
SELECT main.Currency, 
    Average_Cost_for_two,
    (main.average_cost_for_two * currency1.USD) AS USD_Cost
FROM 
    main
INNER JOIN currency1 ON main.Currency = currency1.Currency;


-- 3. Number of Restaurants by City and Country
select c.countryname,m.city,count(*) as "NO_OF_RESTAURANTS" from main m  join country c on c.CountryID=m.CountryCode group by c.Countryname,m.city;

-- 4. Number of Restaurants Opening Based on Year, Quarter, Month
SELECT YEAR(DateKey_opening) AS year,QUARTER(DateKey_opening) AS quarter,MONTH(DateKey_opening) AS month,COUNT(*) AS NO_OF_RESTAURANTS FROM main
GROUP BY YEAR(DateKey_opening),QUARTER(DateKey_opening),MONTH(DateKey_opening)
 ORDER BY YEAR(DateKey_opening),QUARTER(DateKey_opening),MONTH(DateKey_opening);

-- 5. Count of Restaurants by Average Ratings
select case when Rating <=2 then "0-2"
when rating <=3 then "2-3"
when rating <=4 then "3-4"
when rating <=5 then "4-5" end rating_range ,count(*) as "NO_OF_RESTAURANTS" from main
group by rating_range order by rating_range;

-- 6. Buckets by Average Price and Restaurant Count.
select case when Price_range=1 then "0-500"
when Price_range=2 then "500-3000"
when Price_range=3 then "3000-10000"
when Price_range=4 then ">10000"
end price_range,count(*) as "NO_OF_RESTAURANTS" from main group by Price_range order by Price_range;

-- 7.  Percentage of Restaurants Based on "Has Table Booking".
select has_table_booking,(count(*)*100)/(select count(*) from main) as "PERCENTAGE" from main group by Has_Table_booking;

-- 8. Percentage of Restaurants Based on "Has Online Delivery" 
select Has_Online_delivery,(count(*)*100)/(select count(*) from main) as "PERCENTAGE" from main group by Has_Online_delivery;

-- 9. KPI's for Cuisines, City, and Ratings
-- CUISINES
select cuisines,count(*) as "NO_OF_RESTAURANTS" from main group by Cuisines;
-- CUISINES AND RATINGS
select case when Rating <=2 then "0-2"
when rating <=3 then "2-3"
when rating <=4 then "3-4"
when rating <=5 then "4-5" end rating_range ,count(distinct(Cuisines)) as "NO_OF_CUISINES" from main
group by rating_range order by rating_range;
-- City-Wise and Cuisines Breakdown
select distinct(city),cuisines as "CUISINES",count(*) as "NO_OF_RESTAURANTS"from main group by city,Cuisines order by city;
