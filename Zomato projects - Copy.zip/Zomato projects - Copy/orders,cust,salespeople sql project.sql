-- 1. create salespeople table
create database orders__cust_Salespeople;
create table SalesPeople(snum int,sname varchar(20),city varchar(20),comm decimal(5,2));
insert into SalesPeople (snum,sname,city,comm) values
(1001,"Peel","London",0.12),(1002,"Serres","San Jose",0.13),(1003,"Axelrod","New York",0.10),
(1004,"Motika","London",0.11),(1007,"Rafkin","Barcelona",0.15);
select * from salespeople;

-- 2. create customer table
CREATE TABLE Customers (cnum INT PRIMARY KEY,cname VARCHAR(50),city VARCHAR(50),rating INT,snum INT);
INSERT INTO Customers (cnum, cname, city, rating, snum) VALUES
(2001, 'Hoffman', 'London', 100, 1001),
(2002, 'Giovanne', 'Rome', 200, 1003),
(2003, 'Liu', 'San Jose', 300, 1002),
(2004, 'Grass', 'Berlin', 100, 1002),
(2006, 'Clemens', 'London', 300, 1007),
(2007, 'Pereira', 'Rome', 100, 1004),
(2008, 'James', 'London', 200, 1007);
select * from customers;

-- 3. create orders table
CREATE TABLE Orders (onum INT PRIMARY KEY,amt DECIMAL(10, 2),odate DATE,cnum INT,snum INT);
INSERT INTO Orders (onum, amt, odate, cnum, snum) VALUES
(3001, 18.69, '1994-10-03', 2008, 1007),
(3002, 1900.10, '1994-10-03', 2007, 1004),
(3003, 767.19, '1994-10-03', 2001, 1007),
(3005, 5160.45, '1994-10-03', 2003, 1002),
(3006, 1098.16, '1994-10-04', 2008, 1007),
(3007, 75.75, '1994-10-05', 2004, 1002),
(3008, 4723.00, '1994-10-05', 2001, 1001),
(3009, 1713.23, '1994-10-06', 2002, 1003),
(3010, 1309.95, '1994-10-06', 2004, 1002),
(3011, 9891.88, '1994-10-06', 2006, 1001);
select * from orders;

-- 4. Write a query to match the salespeople to the customers according to the city they are living.
select c.cname as "customer",s.sname as "Sales Person",c.city as "City" from customers c join Salespeople s on  c.city=s.city;

-- 5. Write a query to select the names of customers and the salespersons who are providing service to them.
select c.cname as "Customer",s.sname as "Sales Person" from customers c join salespeople s on c.snum=s.snum;

-- 6. Write a query to find out all orders by customers not located in the same cities as that of their salespeople.
select o.onum as "Orders",c.cname as "customer", c.city as "city",S.sname as "SalesPerson",S.city as "City" from orders o join customers c on o.cnum=c.cnum 
join salespeople s on o.snum=s.snum where c.city!=s.city;

-- 7. Write a query that lists each order number followed by name of customer who made that order.
select o.onum as "Orders",c.cname as "Customers" from orders o join customers c on o.cnum=c.cnum;

-- 8. Write a query that finds all pairs of customers having the same rating.
select c1.cname as "Customer 1",c2.cname as "Customer 2", c1.rating as "Rating" from customers c1 join customers c2 on c1.rating=c2.rating where c1.cname>c2.cname;

-- 9. Write a query to find out all pairs of customers served by a single salesperson.
select c1.cname as "Customer 1",c2.cname as "Customer 2",s.sname as "Sales Person" from customers c1 join customers c2 on 
c1.snum=c2.snum join salespeople s on c1.snum=s.snum where c1.cnum<c2.cnum;

-- 10. Write a query that produces all pairs of salespeople who are living in same city.
select s1.sname as "sales person 1",s2.sname as "sales person 2",s1.city as "City" from salespeople s1 join  salesPeople s2 
on s1.city=s2.city where s1.sname>s2.sname;

-- 11. Write a Query to find all orders credited to the same salesperson who services Customer 2008.
SELECT o.onum AS OrderNumber,o.cnum AS CustomerNumber,c.cname AS CustomerName,
o.snum AS SalespersonNumber,s.sname AS SalespersonName,o.odate AS OrderDate,
o.amt AS OrderAmount FROM Orders o
JOIN 
    Customers c ON o.cnum = c.cnum
JOIN 
    Salespeople s ON o.snum = s.snum
WHERE 
    o.snum = (SELECT snum FROM Customers WHERE cnum = 2008);

 
 --  12. Write a Query to find out all orders that are greater than the average for Oct 4th.
 SELECT * FROM orders WHERE amt > (SELECT AVG(amt) FROM orders WHERE odate = '1994-10-04');

 -- 13. Write a Query to find all orders attributed to salespeople in London.
SELECT o.onum AS OrderNumber, o.cnum AS CustomerNumber, c.cname AS CustomerName, s.sname AS Salesperson, o.odate AS OrderDate, o.amt AS OrderAmount
FROM Orders o JOIN Customers c ON o.cnum = c.cnum
JOIN Salespeople s ON o.snum = s.snum
WHERE s.city = 'London';

-- 14.	Write a query to find all the customers whose cnum is 1000 above the snum of Serres. 
SELECT cnum, cname FROM customers WHERE cnum > (SELECT snum + 1000 FROM salespeople WHERE sname = 'Serres');

-- 15. Write a query to count customers with ratings above San Jose’s average rating.
SELECT COUNT(*) as customer_count FROM customers WHERE rating > (SELECT AVG(rating) FROM customers WHERE city = 'San Jose');

-- 16.	Write a query to show each salesperson with multiple customers.
SELECT s.snum as SalespersonNumber,s.sname as SalespersonName,COUNT(c.cnum) as CustomerCount FROM Salespeople s
JOIN Customers c ON s.snum = c.snum GROUP BY s.snum, s.sname HAVING COUNT(c.cnum) > 1;

SELECT 
    o.onum AS OrderNumber,
    o.cnum AS CustomerNumber,
    c.cname AS CustomerName,
    o.snum AS SalespersonNumber,
    s.sname AS SalespersonName,
    o.odate AS OrderDate,
    o.amt AS OrderAmount
FROM 
    Orders o
JOIN 
    Customers c ON o.cnum = c.cnum
JOIN 
    Salespeople s ON o.snum = s.snum
WHERE 
    o.snum = (
        SELECT snum 
        FROM Customers 
        WHERE cnum = 2008
    );


